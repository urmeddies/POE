﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CMCS
{
    public partial class CoordinatorWindow : Window
    {
        public CoordinatorWindow()
        {
            InitializeComponent();
        }

        private void EnterClaimID_Click(object sender, RoutedEventArgs e)
        {
            // Simulate retrieving claim information based on the Claim ID.
            string claimId = txtClaimID.Text;

            
            if (!string.IsNullOrEmpty(claimId))
            {
                // Dummy data for demonstration
                var claimInfo = new[]
                {
                    new
                    {
                        ClaimID = claimId,
                        FullName = "John Doe",
                        LastName = "Doe",
                        HoursWorked = 40,
                        HourlyRate = 100,
                        TotalAmount = 40 * 100 // Calculate TotalAmount here
                    }
                };

                ClaimInfoDataGrid.ItemsSource = claimInfo;
            }
            else
            {
                MessageBox.Show("Please enter a valid Claim ID.");
            }
        }

        private void ApproveClaim_Click(object sender, RoutedEventArgs e)
        {
            string claimId = txtClaimID.Text;

            if (!string.IsNullOrEmpty(claimId))
            {
                MessageBox.Show($"Claim {claimId} has been approved.");
                // Add logic to update claim status in the database
            }
            else
            {
                MessageBox.Show("Please enter a Claim ID.");
            }
        }

        private void DeclineClaim_Click(object sender, RoutedEventArgs e)
        {
            string claimId = txtClaimID.Text;

            if (!string.IsNullOrEmpty(claimId))
            {
                MessageBox.Show($"Claim {claimId} has been declined.");
                // Add logic to update claim status in the database
            }
            else
            {
                MessageBox.Show("Please enter a Claim ID.");
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back to the previous screen
            this.Close();
        }
    }
}



