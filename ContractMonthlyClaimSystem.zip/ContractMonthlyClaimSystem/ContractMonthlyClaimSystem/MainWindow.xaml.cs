﻿using System.Windows;

namespace CMCS
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LecturerLogin_Click(object sender, RoutedEventArgs e)
        {
            LecturerWindow lecturerWindow = new LecturerWindow();
            lecturerWindow.Show();
            this.Close();
        }

        private void CoordinatorLogin_Click(object sender, RoutedEventArgs e)
        {
            CoordinatorWindow coordinatorWindow = new CoordinatorWindow();
            coordinatorWindow.Show();
            this.Close();
        }
    }
}

