﻿using System.Windows;

namespace CMCS
{
    public partial class TrackClaimWindow : Window
    {
        public TrackClaimWindow()
        {
            InitializeComponent();
        }

        private void TrackClaim_Click(object sender, RoutedEventArgs e)
        {
            // Simulate checking claim status based on entered claim ID
            string claimId = txtTrackClaimID.Text;
            MessageBox.Show($"Claim {claimId} is currently pending.");
        }
    }
}


