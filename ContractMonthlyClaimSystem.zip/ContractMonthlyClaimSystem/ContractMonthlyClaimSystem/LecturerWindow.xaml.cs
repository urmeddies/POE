﻿using Microsoft.Win32;
using System;
using System.Globalization;
using System.Windows;

namespace CMCS
{
    public partial class LecturerWindow : Window
    {
        public LecturerWindow()
        {
            InitializeComponent();
        }

        private void BrowseDocument_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                // Logic to store the uploaded document
                MessageBox.Show("Document uploaded: " + openFileDialog.FileName);
            }
        }

        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Check if all fields are filled
            if (string.IsNullOrWhiteSpace(txtClaimID.Text) ||
                string.IsNullOrWhiteSpace(txtFullName.Text) ||
                string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtHoursWorked.Text) ||
                string.IsNullOrWhiteSpace(txtHourlyRate.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            // Validate Hours Worked
            if (!double.TryParse(txtHoursWorked.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out double hoursWorked) || hoursWorked <= 0)
            {
                MessageBox.Show("Hours Worked must be a positive number.");
                return;
            }

            // Validate Hourly Rate
            if (!double.TryParse(txtHourlyRate.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out double hourlyRate) || hourlyRate <= 0)
            {
                MessageBox.Show("Hourly Rate must be a positive number.");
                return;
            }

            // If all validations pass
            MessageBox.Show("Claim submitted. Please use the 'Track Total Claim' button to view your claim details.");
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            // Close the current window
            this.Close();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            // Navigate back to the main window
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void TrackTotalClaim_Click(object sender, RoutedEventArgs e)
        {
            TrackClaimWindow trackClaimWindow = new TrackClaimWindow();
            trackClaimWindow.Show();
        }
    }
}
